#pragma once

//extern "C" int mafonction(long long i);
//__declspec(dllimport) int mafonction(long long i); 

